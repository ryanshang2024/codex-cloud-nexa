# 商业宣传口径核对

Grounding repository: ryanshang2024/codex-cloud-nexa, revision 40e0bf45f74a025641e9dc88953987a7a149732e. Reviewed config/hvac-qc-on.json and docs/acceptance-scorecard.md.

| 片中表述 | 对应依据或边界 |
| --- | --- |
| Québec / Ontario 与服务区域、能力、经营模式画像 | HVAC 两省配置、ICP 模块；不将 H10 排除画像宣传为目标客户 |
| 授权渠道汇聚资料、Source Router | source policies / adapters / evidence 模块；画面明确“渠道经授权后接入”，未宣称供应商已投入运营 |
| 官网资料与资质审核 | evidence / credential 工作流；无具体企业资质声明 |
| Fit 与 Intent 两维评分 | 评分模块；不呈现任何伪造分数或等同成交承诺 |
| 英法开发信一键生成、人工审批 | EN/FR 资料驱动草稿、版本和审批状态；当前不是语义 AI 模型生成 |
| AI 协作与自动触达 | 明确标为“后续接入能力 / 分阶段开放”，没有营销发送或真实模型调用 |
| 询价、技术问题、合作意向进入待办与商机 | 规则回复分类及 CRM 模块；不宣称 AI 自动报价、技术知识库或自主谈判 |
| 跟进有节奏，商机可追溯 | CRM 任务、商机、状态及审计记录；定性经营价值，不承诺增长数字 |

视频没有真实或虚构企业、邮箱、姓名、采购信号、经营业绩、转化百分比、公共站点已部署或加盟政策承诺。仅呈现产品工作流与业务价值，未使用旧录屏中的账户资料。
