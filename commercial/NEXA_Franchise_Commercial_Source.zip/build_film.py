from pathlib import Path
import html, json, math
import numpy as np
import soundfile as sf

ROOT=Path(__file__).resolve().parent; FILM=ROOT/'film'; ASSETS=FILM/'assets'
story=json.loads((ROOT/'narration-manifest.json').read_text())
sr=24000; cursor=0.; captions=[]
for s in story:
    s['start']=cursor
    s['duration']=math.ceil((s['speech_duration']+.95)*24)/24
    if s['id'] in ['s0','s7']: s['duration']+=.5
    s['end']=cursor+s['duration']
    for f in s['fragments']:
        captions.append({'text':f['text'],'start':cursor+.42+f['start'],'end':cursor+.42+f['end']})
    cursor=s['end']
duration=round(cursor,6); assert duration < 60, duration
voice=np.zeros(round(duration*sr),dtype=np.float32)
for s in story:
    a,rate=sf.read(ASSETS/'audio'/f"{s['id']}.wav",dtype='float32'); assert rate==sr
    pos=round((s['start']+.42)*sr); voice[pos:pos+len(a)]+=a
voice*=.82/max(np.max(np.abs(voice)),.01)
sf.write(ASSETS/'narration.wav',voice,sr,subtype='PCM_16')
# Original gentle 108 BPM pulse, no external recording.
music=np.zeros_like(voice); beat=60/108
chords=[(130.81,164.81,196.),(110.,130.81,164.81),(87.31,130.81,174.61),(98.,123.47,146.83)]
for n in range(math.ceil(duration/beat)):
    pos=round(n*beat*sr); length=min(round(beat*1.8*sr),len(music)-pos)
    t=np.arange(length)/sr; f=chords[(n//8)%4][[0,2,1,2][n%4]]*2
    env=np.minimum(t/.015,1)*np.exp(-t*5)
    music[pos:pos+length]+=.024*(np.sin(2*np.pi*f*t)+.13*np.sin(4*np.pi*f*t))*env
    if n%2==0:
        music[pos:pos+length]+=.018*np.sin(2*np.pi*(52*t+14*(1-np.exp(-t*18))/18))*np.exp(-t*18)
music*=np.minimum(np.arange(len(music))/sr/1.2,1)*np.minimum((len(music)-np.arange(len(music)))/sr/1.5,1)
sf.write(ASSETS/'music-original.wav',music,sr,subtype='PCM_16')

def stamp(t):
    n=round(t*1000); h,n=divmod(n,3600000); m,n=divmod(n,60000); sec,ms=divmod(n,1000)
    return f'{h:02}:{m:02}:{sec:02},{ms:03}'
(FILM/'nexa-commercial.zh.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(captions))+'\n')
(FILM/'timeline.json').write_text(json.dumps({'duration':duration,'scenes':story,'captions':captions},ensure_ascii=False,indent=2)+'\n')

def box(id,head,body='',cls='card'):
    return f'<div id="{id}" class="{cls} anim"><h3>{head}</h3>{body}</div>'
panels=[]
panels.append('<div class="hero-art"><div id="s0-mark" class="hero-mark anim" role="img" aria-label="NEXA"></div><div id="s0-promise" class="hero-promise anim">获客 · 开发 · 跟进</div><div id="s0-identity" class="small anim">为加拿大 HVAC 加盟业务而设计</div></div>')
panels.append('<div class="panel"><div class="two">'+box('s1-qc','QUÉBEC','<p>魁北克 · 法语业务</p>','province card')+box('s1-on','ONTARIO','<p>安大略 · 英语业务</p>','province card')+'</div>'+box('s1-criteria','按业务维度建立客户画像','<div class="chips"><span>服务区域</span><span>服务能力</span><span>经营模式</span></div>')+box('s1-segments','匹配加盟业务的合作对象','<p>热泵安装 · 冷暖服务 · 商业 HVAC</p><div class="small">识别目标画像与排除条件</div>','card mint')+'</div>')
panels.append('<div class="panel"><div class="panel-label anim" id="s2-auth">渠道经授权后接入</div><div class="source-grid">'+''.join(box(f's2-source{i}',h,b,'source card') for i,(h,b) in enumerate([('企业目录','<p>授权名单</p>'),('官网资料','<p>企业信息</p>'),('公开注册','<p>资质依据</p>'),('客户表单','<p>主动咨询</p>')]))+'</div>'+box('s2-router','Source Router','<p>授权检查 → 去重整合 → 来源留档</p>','card navy')+box('s2-review','资料丰富化 + 资质审核','<p>保留来源、日期与核验状态</p>','card mint')+'</div>')
panels.append('<div class="panel"><div class="two score-pair">'+box('s3-fit','FIT','<strong>业务适配</strong><p>服务 · 区域 · 企业类别</p>','card score')+box('s3-intent','INTENT','<strong>合作意向</strong><p>回复与可验证行动</p>','card score mint')+'</div>'+box('s3-result','两维评分，统一跟进优先级','<div class="rank"><span>优先推进</span><span>持续培育</span><span>补充资料</span></div>','card navy')+'</div>')
panels.append('<div class="panel"><div class="panel-label anim" id="s4-current">当前流程 · 双语草稿与人工审批</div><div class="two">'+box('s4-en','EN','<strong>英语开发信</strong><p>安大略业务场景</p>','card draft')+box('s4-fr','FR','<strong>法语开发信</strong><p>魁北克业务场景</p>','card draft')+'</div>'+box('s4-approval','客户资料 → 双语草稿 → 人工审批','<p>发送前核查联系依据与退订状态</p>','card mint')+box('s4-future','后续接入能力','<p>AI 协作 · 自动触达</p><div class="small">分阶段开放</div>','card future')+'</div>')
panels.append('<div class="panel"><div id="s5-inbox" class="inbox anim">客户回复</div><div class="routing">'+box('s5-price','询价','<p>报价待办</p>','card route')+box('s5-tech','技术问题','<p>技术跟进</p>','card route')+box('s5-partner','合作意向','<p>合作商机</p>','card route mint')+'</div>'+box('s5-control','统一归档，明确跟进动作','<p>回复分类 · 任务分派 · 拒绝联系控制</p>','card navy')+'</div>')
panels.append('<div class="panel"><div class="pipeline">'+''.join(box(f's6-stage{i}',h,b,'card pipe') for i,(h,b) in enumerate([('发现','<p>建立画像</p>'),('研究','<p>资料与评分</p>'),('开发','<p>草稿与审批</p>'),('跟进','<p>任务与商机</p>')]))+'</div>'+box('s6-crm','CRM 汇聚客户、任务与商机','<div class="chips"><span>负责人</span><span>下一步</span><span>状态记录</span></div>','card mint')+box('s6-history','每一步有记录，每个商机有归属','<p>让团队协作拥有共同的业务视图</p>','card navy')+'</div>')
panels.append('<div class="hero-art closing"><div id="s7-mark" class="hero-mark anim" role="img" aria-label="NEXA"></div><div id="s7-promise" class="hero-promise anim">让加盟商专注合作与增长</div><div id="s7-identity" class="small anim">NEXA AI SALES ENGINE · V3.2</div></div>')
descs=['从目标客户到合作商机，\n为销售团队串起每一步。','面向 Québec 与 Ontario，\n以业务画像建立获客方向。','来源清晰，资料可核验，\n客户研究更有依据。','匹配度与合作意向分开判断，\n支持销售团队安排跟进。','客户信息驱动双语草稿，\n让对外沟通有审核、有依据。','回复转成明确任务，\n把合作意向带入商机管理。','统一客户资料与跟进记录，\n连接个人行动与团队协作。','精准方向 · 可靠依据 · 连贯跟进']
css='''
*{box-sizing:border-box}html,body{margin:0;width:1920px;height:1080px;overflow:hidden;background:#FAFBFC;font-family:"Noto Sans SC",sans-serif;color:#0B1F38}
#root{position:relative;width:1920px;height:1080px;overflow:hidden}.scene{position:absolute;inset:0;background:#FAFBFC;opacity:0;overflow:hidden}.scene-content{width:100%;height:100%;padding:64px 80px;display:flex;flex-direction:column;gap:40px}
.header{height:72px;flex:none;display:flex;align-items:center;justify-content:space-between}.logo{width:200px;height:auto;max-height:70px;object-fit:contain}.header-context{font-size:23px;letter-spacing:.04em;font-weight:700}.body-row{display:grid;grid-template-columns:690px 990px;gap:80px;height:670px;flex:none;align-items:center}.copy{display:flex;flex-direction:column;gap:32px;min-width:0}.kicker{font-size:24px;line-height:36px;letter-spacing:.045em;font-weight:700;color:#071A14}h1{margin:0;font-size:82px;line-height:1.2;letter-spacing:-.035em;font-weight:700;white-space:pre-line}.desc{font-size:29px;line-height:1.65;margin:0;white-space:pre-line}.underline{width:116px;height:7px;background:#22C55E;border-radius:7px}
.panel{width:990px;display:flex;flex-direction:column;gap:22px;padding:26px;background:#E5E7EB;border-radius:32px}.two{display:flex;gap:20px}.two>*{flex:1;min-width:0}.card{padding:26px 30px;background:#FAFBFC;border-radius:20px;border:1px solid #E5E7EB;min-width:0}h3{font-size:30px;line-height:1.35;margin:0;font-weight:700}.card p{font-size:25px;line-height:1.5;margin:12px 0 0}.card strong{display:block;font-size:38px;line-height:1.4;margin-top:14px}.small{font-size:22px;line-height:1.5;margin-top:16px}.mint{background:#CFFADD;color:#071A14;border-color:#CFFADD}.navy{background:#0B1F38;color:#FAFBFC;border-color:#0B1F38}.chips{display:flex;gap:14px;flex-wrap:wrap;margin-top:22px}.chips span{font-size:25px;line-height:38px;padding:6px 16px;border:1px solid #10B981;border-radius:10px;background:#CFFADD;color:#071A14}.province h3{font-size:36px;letter-spacing:.06em}.source-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.source{padding:19px 25px}.source h3{font-size:29px}.source p{font-size:23px;margin-top:5px}.panel-label{font-size:25px;font-weight:700;line-height:36px;padding:0 6px}.score{min-height:280px;display:flex;flex-direction:column;justify-content:center}.score h3{font-size:46px;letter-spacing:.06em}.rank{display:flex;gap:16px;margin-top:24px}.rank span{padding:10px 19px;border:1px solid #38BEFB;border-radius:10px;font-size:25px}.draft{padding:20px 28px}.draft h3{font-size:36px;letter-spacing:.08em}.draft strong{font-size:30px;margin-top:8px}.draft p{font-size:23px;margin-top:6px}.future{background:#FAFBFC;border:2px dashed #0B1F38;display:grid;grid-template-columns:240px 1fr;column-gap:20px;align-items:center;padding:20px 28px}.future h3{font-size:27px}.future p{font-size:28px;margin:0}.future .small{grid-column:2;margin-top:5px}.inbox{align-self:center;width:350px;padding:24px;background:#0B1F38;color:#FAFBFC;border-radius:22px;font-size:38px;font-weight:700;text-align:center}.routing{display:flex;gap:18px;padding-top:24px}.route{flex:1;text-align:center;padding:30px 14px;min-height:180px;display:flex;flex-direction:column;justify-content:center}.route h3{font-size:30px}.route p{font-size:26px}.pipeline{display:grid;grid-template-columns:1fr 1fr;gap:18px}.pipe{padding:20px 28px}.pipe h3{font-size:32px}.pipe p{font-size:24px}.hero-art{height:620px;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:28px;background:#CFFADD;border-radius:40px;color:#071A14}.hero-mark{width:330px;height:330px;object-fit:contain;border-radius:34px}.hero-promise{font-size:42px;line-height:1.4;font-weight:700}.hero-art .small{margin:0;font-size:24px}.closing{background:#CFFADD}.hero-scene h1{font-size:94px}.hero-scene .body-row{grid-template-columns:820px 860px}.caption{position:absolute;left:80px;right:80px;bottom:52px;height:90px;display:flex;align-items:center;justify-content:center;padding:10px 24px;border-radius:16px;background:#0B1F38;color:#FAFBFC;z-index:200;opacity:0}.caption p{font-size:32px;line-height:1.4;margin:0;text-align:center}.progress{position:absolute;left:0;right:0;bottom:0;height:7px;z-index:220;background:#E5E7EB}.progress-fill{height:100%;width:100%;background:#22C55E;transform-origin:left}.anim{opacity:0}
'''
css+='\n.brand{position:absolute;left:80px;top:65px;z-index:150}.brand-space{width:200px;height:70px}.hero-mark{background:url(assets/brand/nexa-symbol.png) center/contain no-repeat}'
E=html.escape; sections=[]; js=['window.__timelines=window.__timelines||{};const tl=gsap.timeline({paused:true});tl.fromTo("#brand",{opacity:0,y:12},{opacity:1,y:0,duration:.52,ease:"power3.out",immediateRender:false},.12);']
assertions=[]
for i,s in enumerate(story):
    id=s['id']; t=s['start']; hero=' hero-scene' if i in [0,7] else ''
    sections.append(f'<section id="{id}" class="scene{hero}" style="z-index:{i+1}"><div class="scene-content"><header class="header"><div class="brand-space"></div><div id="{id}-context" class="header-context anim">加拿大 HVAC · 加盟商业务增长</div></header><main class="body-row"><div class="copy"><div id="{id}-kicker" class="kicker anim">{E(s["kicker"])}</div><h1 id="{id}-title" class="anim">{E(s["title"])}</h1><div id="{id}-line" class="underline anim"></div><p id="{id}-desc" class="desc anim">{E(descs[i])}</p></div>{panels[i]}</main></div></section>')
    # The scene crossfade is the transition; do not fade out individual content.
    if i==0: js.append(f'tl.set("#{id}",{{opacity:1}},0);')
    else:
        tr=t-.35
        js.append(f'tl.fromTo("#{id}",{{opacity:0,x:34}},{{opacity:1,x:0,duration:.35,ease:"power2.inOut",immediateRender:false}},{tr});')
        js.append(f'tl.to("#s{i-1}",{{opacity:0,duration:.35,ease:"sine.inOut"}},{tr});')
    selectors=[f'{id}-{x}' for x in ['context','kicker','title','line','desc']]
    import re
    selectors+=re.findall(r'id="([^"]+)"',panels[i])
    for j,key in enumerate(selectors):
        prop,value,target,ease=[('y',18,0,'power3.out'),('x',22,0,'circ.out'),('scale',.95,1,'sine.out')][j%3]
        at=t+.12+min(j*.06,.60)
        js.append(f'tl.fromTo("#{key}",{{opacity:0,{prop}:{value}}},{{opacity:1,{prop}:{target},duration:.52,ease:"{ease}",immediateRender:false}},{at:.6f});')
    # Quiet settled motion maintains energy without distracting from the voice.
    if i in [0,7]:
        js.append(f'tl.fromTo("#{id}-mark",{{rotation:0}},{{rotation:2,duration:{s["duration"]-1.5},ease:"sine.inOut",immediateRender:false}},{t+1.4});')
    assertions.extend([{'kind':'appearsBy','selector':f'#{id}-title','bySec':round(t+1.6,4)},{'kind':'staysInFrame','selector':f'#{id}-title'}])
for i,c in enumerate(captions):
    js.append(f'tl.set("#caption-{i}",{{opacity:1}},{c["start"]});tl.set("#caption-{i}",{{opacity:0}},{c["end"]});')
    assertions.append({'kind':'staysInFrame','selector':f'#caption-{i}'})
assertions.append({'kind':'staysInFrame','selector':'#s4-future'})
js.append(f'tl.fromTo(".progress-fill",{{scaleX:0}},{{scaleX:1,duration:{duration},ease:"none"}},0);window.__timelines["nexa-commercial"]=tl;')
font_css=(ASSETS/'fonts/fonts.css').read_text().replace('url(./','url(assets/fonts/')
caption_html=''.join(f'<div class="caption" id="caption-{i}"><p>{E(c["text"])}</p></div>' for i,c in enumerate(captions))
document=f'<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><title>NEXA 加盟商商业宣传片</title><script src="assets/gsap.min.js"></script><style>{font_css}\n{css}</style></head><body><div id="root" data-composition-id="nexa-commercial" data-start="0" data-duration="{duration}" data-width="1920" data-height="1080">'+''.join(sections)+'<img id="brand" class="logo brand anim" src="assets/brand/nexa-logo.png" alt="NEXA">'+caption_html+f'<div class="progress" data-layout-ignore><div class="progress-fill"></div></div><audio id="narration" data-start="0" data-duration="{duration}" data-track-index="2" data-volume="1" src="assets/narration.wav"></audio><audio id="music" data-start="0" data-duration="{duration}" data-track-index="3" data-volume="1" src="assets/music-original.wav"></audio></div><script>'+''.join(js)+'</script></body></html>'
(FILM/'index.html').write_text(document)
(FILM/'index.motion.json').write_text(json.dumps({'duration':duration,'assertions':assertions},ensure_ascii=False,indent=2)+'\n')
fm=[';FFMETADATA1','title=NEXA AI Sales Engine V3.2 — 加盟商商业宣传片','comment=Franchisee product capabilities. AI collaboration and automatic outreach are phased future integrations.']
for s in story: fm+=['[CHAPTER]','TIMEBASE=1/1000',f'START={round(s["start"]*1000)}',f'END={round(s["end"]*1000)}','title='+s['title'].replace('\n',' · ')]
(FILM/'chapters.ffmetadata').write_text('\n'.join(fm)+'\n')
print('Duration:',duration,'seconds. Caption cues:',len(captions),flush=True)
print('Snapshots:',','.join(str(round(s['start']+min(2.3,s['duration']/2),3)) for s in story),flush=True)
