# NEXA 加盟商商业宣传片

Purpose: a Chinese narrated, commercially presentable film under 60 seconds for HVAC franchisees. Present the real sales operating sequence and repository-supported product capabilities, with clear business wording for future integrations.

Brand: original NEXA logo and symbol from the supplied VI. Navy #0B1F38, emerald #10B981, green #22C55E, mint #CFFADD, white #FAFBFC, sky #38BEFB, dark green #071A14. Noto Sans SC at 400 and 700 is the explicit brand font, overriding generic typography defaults. Keep original logo proportions.

Format: 1920 × 1080, 24 fps, target 52–59 seconds. Chinese voice and burned-in Chinese captions, calm upbeat original instrumental bed. Opening and closing use oversized brand typography; intervening chapters use large editorial headlines, diagrams, routing cards and process motion. 80 px margins, content above y=880, caption band at y=934. Avoid dense text, decorative charts and fake customer records.

Story: growth → Québec / Ontario profiles → authorized source collection and evidence → Fit and Intent → English/French draft plus human approval → reply routing → CRM continuity → brand close. Show source provenance and credential review as processes, never invented verified company evidence. No numeric success/ROI claims without supplied supporting data. Actual semantic AI and automatic outreach are future integration capabilities and must be labelled clearly as such in their chapter.

Motion: deterministic paused GSAP timeline registered synchronously. Each scene fades out as the next reveals. Titles and cards have separate staged entrances, followed by subtle nonlooping diagram motion. All moving elements use explicit fromTo states; initial opacity is defined. Audio is controlled by the composition runner. No unreviewed installation or remote font/music/asset requests.

Commercial copy avoids testing/simulation terminology by depicting product workflows without fictional leads. It does not represent the illustrative cards as actual company records, active live suppliers or measured sales performance. No invented contacts, business signals, percentages, live deployment URL, or automatic message sending claim.
